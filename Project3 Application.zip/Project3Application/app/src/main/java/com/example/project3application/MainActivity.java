package com.example.project3application;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MainActivity extends AppCompatActivity {

    AppDatabase data;
    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        data = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "users").build();
    }

    public void CreateClick(View view){
        this.view = view;
        EditText usernameText = findViewById(R.id.editUsername);
        EditText passwordText = findViewById(R.id.editPassword);
        String nameValue = usernameText.getText().toString();
        String passwordValue = passwordText.getText().toString();
        if(!checkLogin(nameValue, passwordValue)){
            createUser(nameValue, passwordValue);
        }
    }

    public void LoginClick(View view){
        EditText usernameText = findViewById(R.id.editUsername);
        EditText passwordText = findViewById(R.id.editPassword);
        String nameValue = usernameText.getText().toString();
        String passwordValue = passwordText.getText().toString();
        if(checkLogin(nameValue, passwordValue)){
            setContentView(R.layout.main_display);
        }
    }

    private boolean checkLogin(String username, String password){
        UserDao userDao = data.userDao();
        User user = userDao.findByName(username, password);
        return user != null;
    }

    private void createUser(String username, String password){
        UserDao userDao = data.userDao();
        User user = new User();
        user.userName = username;
        user.password = password;
        userDao.insertAll(user);
    }

    public void setView(View view) {
        this.view = view;
    }

    public View getView() {
        return view;
    }
}

